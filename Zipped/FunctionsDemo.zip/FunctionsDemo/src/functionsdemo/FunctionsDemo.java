package functionsdemo;

import java.util.Scanner;
import java.math.BigInteger;
public class FunctionsDemo {    
    
    public static void main(String[] args) {   
        
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter a value for X: ");
        int x = keyboard.nextInt();
        System.out.print("Enter a value for Y: ");
        int y = keyboard.nextInt();
        System.out.print("Enter a value for Z: ");
        int z = keyboard.nextInt();
        System.out.print("Enter a value for W: ");
        int w = keyboard.nextInt();
        
        System.out.printf("%d is the minimum value of %d, %d, %d, and %d\n",myMinimum(x,y,z,w),x,y,z,w);
        System.out.printf("%d is the maximum value of %d, %d, %d, and %d\n",myMaximum(x,y,z,w),x,y,z,w);        
                
        //System.out.println(Math.E);
//        BigInteger fact_25000=factorial(25000);
//        BigInteger fact_15000=factorial(15000);
//        BigInteger fact_10000=factorial(10000);
//        
//        System.out.println("C(25000,10000)="+fact_25000.divide(fact_15000.multiply(fact_10000)));
    }
    
    public static BigInteger factorial(long n)
    {
        BigInteger f = BigInteger.ONE;

        if ( n < 0 )
        {
            f.negate();
        }
        for(int count=1;count <= n; count++)
        {
            f=f.multiply( BigInteger.valueOf(count) );
        }
        
        return f;
    }
    
    public static int myMinimum(int x, int y, int z, int w)
    {
        int result=x;
        if ( y < result ) result=y;
        if ( z < result ) result=z;
        if ( w < result ) result=w;
        return result;
    }
    
    public static int myMaximum(int w, int x, int y, int z)
    {
        return Math.max(Math.max(Math.max(w,x),y), z);
    }
}
