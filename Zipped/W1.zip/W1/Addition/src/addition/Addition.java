/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addition;

/*
 * @author Abdul-Hakim
 */

//Adds up two numbers then outputs their sum 

public class Addition {
   
    /*
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 

        double x = 6.45; //1st number 
        double y  = 3.13; //2nd number
        double sum; //sum of the numbers 

        sum = x+y; // adds the numbers, then stores total in sum 

        System.out.printf("Sum is %s%n", sum); //displays sum 
    } //ends main method 
    
} //ends class method 
